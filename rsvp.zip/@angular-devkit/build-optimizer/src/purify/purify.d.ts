export declare function purify(content: string): string;
