"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const error_1 = require("./error");
class InvalidStateError extends error_1.JsonSchemaErrorBase {
}
exports.InvalidStateError = InvalidStateError;
class Serializer {
}
exports.Serializer = Serializer;
//# sourceMappingURL=/users/hansl/sources/angular-cli/src/serializer.js.map