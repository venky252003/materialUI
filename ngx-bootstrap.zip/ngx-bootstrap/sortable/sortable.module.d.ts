import { ModuleWithProviders } from '@angular/core';
export declare class SortableModule {
    static forRoot(): ModuleWithProviders;
}
