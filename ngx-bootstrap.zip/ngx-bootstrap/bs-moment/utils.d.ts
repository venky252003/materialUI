export declare function zeroFill(num: number, targetLength: number, forceSign?: boolean): string;
export declare function mod(n: number, x: number): number;
export declare function absFloor(number: number): number;
export declare function createUTCDate(y?: number, m?: number, d?: number, h?: number, M?: number, s?: number, ms?: number): Date;
