import { UnitOfTime } from '../types';
export declare function startOf(date: Date, units: UnitOfTime): Date;
export declare function endOf(date: Date, units: UnitOfTime): Date;
