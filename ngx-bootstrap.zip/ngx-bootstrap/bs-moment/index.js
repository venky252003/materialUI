export { defineLocale, getSetGlobalLocale, listLocales } from './locale/locales.service';
//# sourceMappingURL=index.js.map