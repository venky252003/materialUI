import './en';
//# sourceMappingURL=index.js.map