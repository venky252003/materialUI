export declare function daysInMonth(year: number, month: number): number;
