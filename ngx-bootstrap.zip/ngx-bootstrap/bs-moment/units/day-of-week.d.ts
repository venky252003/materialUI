import { Locale } from '../locale/locale.class';
export declare function getLocaleDayOfWeek(date: Date, locale: Locale): number;
export declare function getISODayOfWeek(date: Date): number;
