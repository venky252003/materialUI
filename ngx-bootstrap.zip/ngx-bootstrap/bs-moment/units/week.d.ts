import { Locale } from '../locale/locale.class';
export declare function getWeek(date: Date, locale: Locale): number;
export declare function getISOWeek(date: Date): number;
