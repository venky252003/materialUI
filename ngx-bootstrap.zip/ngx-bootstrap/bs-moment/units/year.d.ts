export declare function daysInYear(year: number): number;
export declare function isLeapYear(year: number): boolean;
