export declare function getDayOfYear(date: Date): number;
export declare function _getDayOfYear(date: Date): number;
