var BsComponentRef = (function () {
    function BsComponentRef() {
    }
    return BsComponentRef;
}());
export { BsComponentRef };
//# sourceMappingURL=bs-component-ref.class.js.map