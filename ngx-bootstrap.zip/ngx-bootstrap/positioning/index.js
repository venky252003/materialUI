export { positionElements, Positioning } from './ng-positioning';
export { PositioningService } from './positioning.service';
//# sourceMappingURL=index.js.map