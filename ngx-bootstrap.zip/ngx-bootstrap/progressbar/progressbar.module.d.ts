import { ModuleWithProviders } from '@angular/core';
export declare class ProgressbarModule {
    static forRoot(): ModuleWithProviders;
}
