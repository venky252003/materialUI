export { RatingComponent } from './rating.component';
export { RatingModule } from './rating.module';
