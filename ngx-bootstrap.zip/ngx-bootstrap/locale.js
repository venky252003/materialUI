export { ar } from './bs-moment/i18n/ar';
export { de } from './bs-moment/i18n/de';
export { enGb } from './bs-moment/i18n/en-gb';
export { es } from './bs-moment/i18n/es';
export { esDo } from './bs-moment/i18n/es-do';
export { esUs } from './bs-moment/i18n/es-us';
export { fr } from './bs-moment/i18n/fr';
export { hi } from './bs-moment/i18n/hi';
export { it } from './bs-moment/i18n/it';
export { ja } from './bs-moment/i18n/ja';
export { ko } from './bs-moment/i18n/ko';
export { nl } from './bs-moment/i18n/nl';
export { nlBe } from './bs-moment/i18n/nl-be';
export { pl } from './bs-moment/i18n/pl';
export { ptBr } from './bs-moment/i18n/pt-br';
export { ru } from './bs-moment/i18n/ru';
export { zhCn } from './bs-moment/i18n/zh-cn';
//# sourceMappingURL=locale.js.map