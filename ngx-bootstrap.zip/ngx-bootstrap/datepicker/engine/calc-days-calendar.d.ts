import { DaysCalendarModel, MonthViewOptions } from '../models/index';
export declare function calcDaysCalendar(startingDate: Date, options: MonthViewOptions): DaysCalendarModel;
