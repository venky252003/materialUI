import { DatepickerFormatOptions, MonthsCalendarViewModel } from '../models/index';
export declare function formatMonthsCalendar(viewDate: Date, formatOptions: DatepickerFormatOptions): MonthsCalendarViewModel;
