export declare class BsCalendarLayoutComponent {
}
