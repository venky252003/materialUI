export declare class BsCurrentDateViewComponent {
    title: string;
}
