import { MiniStore } from '../../mini-ngrx/store.class';
import { BsDatepickerState } from './bs-datepicker.state';
export declare class BsDatepickerStore extends MiniStore<BsDatepickerState> {
    constructor();
}
