import { ModuleWithProviders } from '@angular/core';
export declare class BsDatepickerModule {
    constructor();
    static forRoot(): ModuleWithProviders;
}
