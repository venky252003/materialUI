import { ModuleWithProviders } from '@angular/core';
export declare class PaginationModule {
    static forRoot(): ModuleWithProviders;
}
