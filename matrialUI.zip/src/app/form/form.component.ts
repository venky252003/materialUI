import { Component } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

@Component({
    moduleId: module.id,
    selector: 'form-template',
    templateUrl: 'form.component.html',
    styleUrls: ['form.component.css']
})
export class FormComponent {
    Personal: string;
    Eligible: string;
    StartDate: string;
    Sex: string = 'male';
    NameFormControl = new FormControl('', [Validators.required]);
    selectedValue: string;

    foods = [
        { value: 'steak-0', viewValue: 'Steak' },
        { value: 'pizza-1', viewValue: 'Pizza' },
        { value: 'tacos-2', viewValue: 'Tacos' }
    ];

    favoriteSeason: string;
    
    
      seasons = [
        'Winter',
        'Spring',
        'Summer',
        'Autumn',
      ];

      TypeChange(event){
        this.Sex = event;
          console.log(this.Sex);
      }

}
