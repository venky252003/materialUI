import { NgModule } from '@angular/core';
import {MdAutocompleteModule, MdCheckboxModule, MdTabsModule, 
  MdInputModule, MdDatepickerModule, MdNativeDateModule, MdRadioModule, MdSelectModule, MdMenuModule
 } from '@angular/material';

@NgModule({
  imports: [MdAutocompleteModule, MdCheckboxModule, MdTabsModule, MdInputModule, 
    MdDatepickerModule, MdNativeDateModule, MdRadioModule, MdSelectModule, MdMenuModule],
  exports: [MdAutocompleteModule, MdCheckboxModule, MdTabsModule, MdInputModule, 
    MdDatepickerModule, MdNativeDateModule, MdRadioModule, MdSelectModule, MdMenuModule],
})
export class MaterialModule { }