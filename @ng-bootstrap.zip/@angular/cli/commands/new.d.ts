declare const NewCommand: any;
export default NewCommand;
