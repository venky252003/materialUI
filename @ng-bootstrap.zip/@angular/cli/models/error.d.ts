export declare class NgToolkitError extends Error {
    constructor(message?: string);
}
