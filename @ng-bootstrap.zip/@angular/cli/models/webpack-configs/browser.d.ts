import { WebpackConfigOptions } from '../webpack-config';
export declare function getBrowserConfig(wco: WebpackConfigOptions): {
    plugins: any[];
};
