export declare class A11yModule {
}
export * from './live-announcer';
export * from './fake-mousedown';
export * from './focus-trap';
export * from './interactivity-checker';
export * from './list-key-manager';
export * from './activedescendant-key-manager';
export * from './focus-key-manager';
