export declare class PlatformModule {
}
export * from './platform';
export * from './features';
