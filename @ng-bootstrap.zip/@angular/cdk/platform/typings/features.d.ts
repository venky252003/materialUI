/** @returns The input types supported by this browser. */
export declare function getSupportedInputTypes(): Set<string>;
