export * from './data-source';
export * from './table';
export * from './cell';
export * from './row';
export declare class CdkTableModule {
}
