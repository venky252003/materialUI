# script loader for webpack

## Usage

``` javascript
require("script!./file.js");
// => execute file.js once in global context
```

[Documentation: Using loaders](http://webpack.github.io/docs/using-loaders.html)

Does nothing in node.js.

## License

MIT (http://www.opensource.org/licenses/mit-license.php)
