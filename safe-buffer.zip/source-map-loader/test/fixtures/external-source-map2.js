with SourceMap
//#sourceMappingURL=data/external-source-map2.map
// comment