with SourceMap
//#sourceMappingURL=external-source-map.map
// comment