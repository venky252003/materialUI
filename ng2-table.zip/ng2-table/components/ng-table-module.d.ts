export declare class Ng2TableModule {
}
